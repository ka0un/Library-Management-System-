<?php
include(__DIR__ . '/auth/session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <H1>Welcome To Homepage</H1>
    <br>
    <a href="debug.php">Debug</a>
    <br>
    <a href="logout.php">Logout</a>
</body>
</html>
